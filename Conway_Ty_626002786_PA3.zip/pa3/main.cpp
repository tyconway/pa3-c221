#include "Tasks.h"

int main() {
    // taskNumbers();
    taskInsert(100000, 500);
    // taskInsertRemove(100000, 500);
}
