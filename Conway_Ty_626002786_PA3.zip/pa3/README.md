# pa3
Three implementations of a priority queue.

# Development
Dr. Tyagi recommended trying the following cases:
1. Modify the sorted pq to check if insert > last, append : run sort.
2. Test the sorted pq against its worst case (all decreasing)
3. Test the heap pq against its worst case (all decreasing)

Need to test much more N 100K+
Need to downheap heap and check the removal (since insert/remove is not growing)
